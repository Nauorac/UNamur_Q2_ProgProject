#-*- coding: utf-8 -*-
import blessed, math, os, time
term = blessed.Terminal()
"""

    """
=======================================================
                    U.I. ENGINE
=======================================================

	map creator
		def_game_mode_selection_displayer
	HUD manager
		def_display_logs
		def_update_players_totallife
		def_turn_updater
	map_updater
		def_remove_death_entities
    """

def myfunction(...):
	"""Description of the function


    Uses:
    -----
    ...

    Args:
    -----

    Arg : Description - type

    Returns:
    --------

	type : Description

	Version:
	--------
	specification : Author (v.1.0 - dd/mm/yyyy)
	code : Author (v.1.0 - dd/mm/yyyy)

