"""
    =================================
                    A.I. ENGINE
    =================================
"""
"""
Il faut générer un dico avec les ww de l'équipe de l'I.A.
Il faut générer un dico avec la team adverse


idées ordres

(x,y) = coord ww I.A.
(r,c) = coord ww adversaire

move

dir_X
dir_Y

if x-r > 1:
    move
    dir_X = 1
    elif x-r = 1
        attack
        feed





"""

def orders_generator():
    """Description of the function


    Uses:
    -----
    ...

    Args:
    -----

    Arg: Description - type

    Returns:
    --------

    type: Description

    Version:
    --------
    specification: Author(v.1.0 - dd/mm/yyyy)
    code: Author(v.1.0 - dd/mm/yyyy)

    """
