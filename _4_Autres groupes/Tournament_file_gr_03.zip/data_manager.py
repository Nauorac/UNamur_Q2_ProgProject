"""Module providing Game main code for UNamur programmation project (INFOB132).

Other modules are used 

"""

__author__ = ["Esteban Barracho <esteban.barracho@student.unamur.be>", 
              "Yannis Van Achter <yannis.van.achter@student.unamur.be", ]
__date__   = "17 march 2022"
__version__= "v1.02.1"

# --- Modules ---
import os , os.path as pt , pickle 
import platform
from random import *


# --- Fonction ---
def load_file():
    """load file contain the map for game.
    Return:
    ------
    loaded_file: list of line from the file (list)
    Versions:
    --------
    specification: Yannis Van Achter and Esteban Barracho (v.1 05/02/2022 -> v.2 09/03/22)
    implementation: Esteban Barracho (v.1 05/02/2022 -> v.2 26/02/22 -> v.3 16/03/22)
    """
    # check the OS and get the current repertory from C:
    ext = platform.system()
    path = __file__
    path_pass = [i for i in path]
    path_pass.reverse()
    checked = []
    stop = False

    for check in path_pass:
        if ext == 'Linux':
            if check == '/':
                stop = True
        elif ext == 'Windows':
            if check == '\\':
                stop = True
        if stop:
            checked.append(check)
    checked.reverse()
    path = ''
    for element in checked:
        path += element

    # create the path to .ano file
    file_Dir = rf"{path}"
    file_Ext = r".ano"
    map = [_ for _ in os.listdir(file_Dir) if _.endswith(file_Ext)][0] # look for .ano file in current repertory
    fh = open(f"{path}{map}", 'r')
    loaded_file = fh.read()
    fh.close()

    return loaded_file.split('\n')


def create_map(size_str, db):
    """create a map

    Parameters:
    -----------
        size_str : x y (str)
        db : data base of game (dic)

    Return:
    -------
        db : upgraded data base of game (dic)

    Version:
    --------
        specification: Yannis Van Achter (v.2 10/02/2022)
        implementation: Yannis Van Achter (v.2 10/02/2022)
    """
    return [set_board_value(int(str.split(size_str, ' ')[0])),
            set_board_value(int(str.split(size_str, ' ')[1]), maxi=60)]


def set_board_value(size, mini=20, maxi=40):
    """set size value if error

    Parameters:
    -----------
        size (int): enterend size
        min : minimum size of the board. Defaults to 20.(int, optional)
        max : maximum size of the board. Defaults to 40.(int, optional)

    Return:
    ------
        [int]: size choosed

    Versions:
    --------
        specification: Yannis Van Achter and Esteban Barracho (v.1 10/02/2022 -> v.2 16/03/22)
        implementation: Yannis Van Achter (v.1 10/02/2022)
    """
    return maxi if size > maxi else (mini if size < mini else size)


def add_wolves(line, db):
    """add wolves in there team and set spawn point and heath point

    Parameters:
    -----------
        line : 'x y type heathpoint' (str)
        db : data base of the game (dic)

    Return:
    -------
        db: data base of the game upgraded (dic)

    Version:
    --------
        specification: Yannis Van Achter (v.1 07/02/2022)
        implementation: Yannis Van Achter (v.2 10/02/2022)
    """
    line_split = str.split(line, ' ')

    is_not_unique = True # create an random id for key in dictionnary
    while is_not_unique:
        type_wolve = line_split[3] + str(randint(0, 10000))
        is_not_unique = type_wolve in db['werewolves']

    # data structure : "type"+id : [player , [y,x] , energy , passified , bonus]
    db['werewolves'][type_wolve] = [int(line_split[0]), [int(line_split[1]), int(line_split[2])], 100, False, 0]

    return db


def add_food(line, db):
    """add wolves in there team and set spawn point and heath point

    Parameters:
    -----------
        line : 'x y type heathpoint' (str)
        db : data base of the game (dic)

    Return:
    -------
        db: data base of the game upgraded (dic)

    Version:
    --------
        specification: Yannis Van Achter (v.1 07/02/2022)
        implementation: Yannis Van Achter (v.2 10/02/2022)
    """
    line_split = str.split(line, ' ')

    is_not_unique = True # create an random id for key in dictionnary
    while is_not_unique:
        food_type = line_split[2] + str(randint(0, 10000))
        is_not_unique = food_type in db['foods']

    # data structure "type"+id : [[y,x] , energy]
    db['foods'][food_type] = [[int(line_split[0]), int(line_split[1])], int(line_split[3])]

    return db


def data_create():
    """create all data request for the game

    Parameter:
    ----------
        file_path : path to file to  create map(str)

    Return:
    -------
        db: game database (dic)

    Version:
    --------
        specification: Yannis Van Achter (v.1 10/02/2022)
        implementation: Yannis Van Achter (v.1 10/02/2022)
    """
    file = load_file()
    db_alpha_game = {}
    processing = None
    for line in file:
        if line != '':
            if line == 'map:':
                processing = line[:-1]
            elif line == 'werewolves:':
                processing, db_alpha_game['werewolves'] = line[:-1], {}
            elif line == 'foods:':
                processing, db_alpha_game['foods'] = line[:-1], {}

            elif processing == 'map' and line != 'map:':
                db_alpha_game['map'] = create_map(line, db_alpha_game)
            elif processing == 'werewolves' and line != 'werewolves:':
                db_alpha_game = add_wolves(line, db_alpha_game)
            elif processing == 'foods' and line != 'foods:':
                db_alpha_game = add_food(line, db_alpha_game)

    return db_alpha_game


def move_entity(wolve, new_coord, db):
    """move data from old coordinate to new and delete old

    Parameters:
    -----------
        wolve : wolve name (str)
        new_coord : new coordonate (list)
        db : data base of game (dic)

    Returns:
    -------
        db: database update (dic)
        (bool): a boolean True or False (bool)

    Versions:
    --------
        specification: Yannis Van Achter and Esteban Barracho (v.1 10/02/2022 -> v.2 16/03/22)
        implementation: Yannis Van Achter (v.1 10/02/2022)
    """
    if wolve in db['werewolves']:
        db['werewolves'][wolve][1] = new_coord
        return db, True
    return db, False


def attack(attack_name, target_name, db):
    """attack the other wolve

    Parameters:
    -----------
        attack_name : (y,x) (tuple)
        target_name : (y,x) (tuple)
        db : database of game (dict)
        copy : copy of db on wich order are applied (dict)

    Return:
    -------
        db : upgrade database of game (dict)

    Version:
    --------
        specification: Yannis Van Achter (v.1 11/02/2022)
        implementation: Yannis Van Achter (v.1 11/02/2022)
    """
    if target_name in db['werewolves'] and attack_name in db['werewolves']:
        attack_point = ((db['werewolves'][attack_name][2] + db['werewolves'][attack_name][4]) / 10)
        if attack_point >= (int(attack_point) + 0.5):
            attack_point = 1 + int(attack_point)
        db['werewolves'][target_name][2] -= int(attack_point)
    return db


def eat(wolve, food_source, db):
    """give health to wolve and substract heath to food

    Parameters:
    -----------
        wolve : name of wolve (str)
        food_source : name of food (str)
        db : database of game (dict)

    Return:
    -------
        db : database updated (dict)

    Version:
    --------
        specification: Yannis Van Achter (v.1 11/02/2022)
        implementation: Yannis Van Achter (v.1 11/02/2022)
    """
    if wolve in db['werewolves'] and food_source in db['foods']:
        while db['foods'][food_source][1] > 0 and db['werewolves'][wolve][2] < 100:
            db['werewolves'][wolve][2] += 1
            db['foods'][food_source][1] -= 1
    return db

if __name__=='__main__':
    print(data_create())