"""Module providing utils features for UNamur programmation project (INFOB132).

"""

__author__ = ["Yannis Van Achter <yannis.van.achter@student.unamur.be", ]
__date__   = "09 may 2022"
__version__= "v1.04.1"

# === modules ===
import logging

from data_manager import attack, eat, move_entity


# === function ===
def order_prosses(db, order):
    """db modification proccess

    Parameters:
    -----------
        db : database of game (dict)
        order : input of player (dict)

    Return:
    -------
        db : dictionnary of all modification to do the data baser (dic)

    Version:
    --------
        specification: Yannis Van Achter (v.1 11/02/2022)
        implementation: Yannis Van Achter (v.2 13/02/2022)
    """
    db, passifier, used_wolves = pacified(db, orders=order)  # pacification if request
    # When we put a argument name with '=' we can atribute the variable of the code we want
    # It allow us to not enter the argument we don't need

    db = get_bonus(db)

    db, used_wolves = get_eat(db, order, used_wolves)

    db, used_wolves, attacked = fight(db, order, used_wolves)

    db, used_wolves, has_move, moved_wolves = get_move_order(db, order, used_wolves)

    db = get_bonus(db, False) # take off the bonus of each wolve (set to 0)

    db, passifier, used_wolves = pacified(db, passifier=passifier, value=False)  # unpacification
    # When we put a argument name with '=' we can atribute the variable of the code we want
    # It allow us to not enter the argument we don't need

    return db, has_move, moved_wolves, attacked




def get_move_order(db, orders, used_wolves):
    """init to wolves to move

    Parameters:
    -----------
        db : data base of game (dict)
        orders : List of all order (dict)
        used_wolves : list of used wolves (list)

    Return:
    ------
        db : data base of game (dict)
        used_wolves: the wolve used (list)
        has_move: to know if a wolf has moved (bool)
        moved_wolves: a list containing all the contact details of the wolves that have moved (list)

    Versions:
    --------
        Spécification: Yannis Van Achter and Esteban Barracho (v1 23/02/2022 -> v.2 16/03/22)
        Implémentation: Yannis Van Achter (v2 02/03/2022)
    """
    has_move, moved_wolves = False, []
    for player in orders:
        for order in orders[player]:
            if order != '':
                order = str.split(order, ':')
                wolve_coord = get_entity_coord(str.strip(order[0]))
                wolve = get_entity_name_on_coord(db['werewolves'], wolve_coord , 1)
                if wolve in db['werewolves'] and str.startswith(order[1], '@') and (wolve not in used_wolves):
                    new_coord = get_entity_coord(str.strip(order[1][1:]))  # saut de 1 pour aller direct après le '@'
                    if can_move(new_coord, wolve, db) and db['werewolves'][wolve][0] == player:
                        moved_wolves.append(wolve_coord)
                        db, has_move = move_entity(wolve, new_coord, db)
                        used_wolves.append(wolve)

    return db, used_wolves, has_move, moved_wolves


def pacified(db, passifier=[], value=True, orders={}):
    """pacify or unpacify wolve of game

    Parameters:
    -----------
        db : data base of game (dict)
        passifier : all pacified wolve (list)
        value : True if wolve must be passified, False otherwise (bool)
        orders : List of all order (dict)

    Returns:
    --------
        db: data base of game (dict)
        passifier: list of passified wolves (list)
        used_wolves: list of wolves already used by users (list)

    Version:
    --------
        Spécification : Yannis Van Achter (v1. 17/02/2022)
        Implémentation : Yannis Van Achter (v2. 02/03/2022)
    """
    used_wolves = []
    if value:
        for player in orders:
            for order in orders[player]:
                if order != '':
                    order = str.split(order, ':')
                    wolve_coord = get_entity_coord(str.strip(order[0]))
                    wolve = get_entity_name_on_coord(db['werewolves'], get_entity_coord(str.strip(order[0])) , 1)
                    if wolve in db['werewolves']:
                        if str.startswith(order[1].lower(), 'pacify') and str.startswith(wolve.lower(), 'omega') \
                                and db['werewolves'][wolve][2] >= 40 and db['werewolves'][wolve][0] == player:
                            db['werewolves'][wolve][2] -= 40
                            used_wolves.append(wolve)
                            for y in range(wolve_coord[0] - 6, wolve_coord[0] + 7):
                                for x in range(wolve_coord[0] - 6, wolve_coord[0] + 7):
                                    entity = get_entity_name_on_coord(db['werewolves'], [y, x], 1)
                                    if entity != None and entity in db['werewolves']:
                                        db['werewolves'][entity][3] = value
                                        passifier.append(entity)

    else:
        for wolve in passifier:
            db['werewolves'][wolve][3] = value
            passifier.remove(wolve)

    return db, passifier, used_wolves


def get_bonus(db, bonus=True):
    """assin or not the bonus to wolves

    Parameters:
    -----------
        db : data base of game (dict)
        bonus : True to set bonus, false if we put bonus to 0. Defaults to True.(bool, optional)

    Return:
    -------
        db : data base of game (dic)

    Version:
    --------
        Spécification: Yannis Van Achter (v1 23/02/2022)
        Implémentation: Yannis Van Achter (v2 02/03/2022)
    """
    if bonus:
        for wolve in db['werewolves']:
            wolve_coord = db['werewolves'][wolve][1]
            if str.startswith(wolve, 'alpha'):
                for y in range(wolve_coord[0] - 4, wolve_coord[0] + 5):
                    for x in range(wolve_coord[1] - 4, wolve_coord[1] + 5):
                        entity = get_entity_name_on_coord(db['werewolves'], [y, x] , 1)
                        if entity != None and db['werewolves'][entity][0] == db['werewolves'][wolve][0] \
                            and db['werewolves'][entity][2] > 0 and db['werewolves'][wolve][2] > 0:
                            db['werewolves'][wolve][4] += 30 if str.startswith(entity.lower(), 'alpha') else 10
            else:
                for y in range(wolve_coord[0] - 2, wolve_coord[0] + 3):
                    for x in range(wolve_coord[1] - 2, wolve_coord[1] + 3):
                        entity = get_entity_name_on_coord(db['werewolves'], [y, x] , 1)
                        if entity != None and db['werewolves'][entity][0] == db['werewolves'][wolve][0] \
                            and db['werewolves'][entity][2] > 0 and db['werewolves'][wolve][2] > 0:
                            db['werewolves'][wolve][4] += 30 if str.startswith(entity.lower(), 'alpha') else 10
    else:
        for wolve in db['werewolves']:
            db['werewolves'][wolve][4] = 0

    return db

def get_distance(wolve1, wolve2):
    """Return the exact distance between 2 wolves as an absolute value

    Parameters:
    -----------
        wolve1 : [y,x] Coordonate of the first wolve (list[int])
        wolve2 : [y,x] Coordonate of the second wolve (list[int])

    Return:
    -------
        distance: the distance between wolves (int)

    Versions:
    --------
        spécification : Ghita Sahlal and Yannis Van Achter(v2 . 05/03/2022 -> v.3 16/03/22)
        implémentation : Ghita Sahlal and Yannis Van Achter (v2 . 05/03/2022)
    """
    return max(abs(wolve2[0] - wolve1[0]), abs(wolve2[1] - wolve1[1]))

def get_eat(db, orders, used_wolves):
    """init to wolves to eat

    Parameters:
    -----------
        db : data base of game (dict)
        orders : List of all order (dict)
        used_wolves : list of used wolves (list)

    Return:
    ------
        db : data base of game (dict)
        used_wolves: the wolve used (list)

    Versions:
    --------
        Spécification: Yannis Van Achter and Esteban Barracho (v1 23/02/2022 -> v.2 16/03/22)
        Implémentation: Yannis Van Achter (v2 02/03/2022)
    """
    for player in orders:
        for order in orders[player]:
            if order != '':
                order = str.split(order, ':')
                wolve_coord = get_entity_coord(str.strip(order[0]))
                wolve = get_entity_name_on_coord(db['werewolves'], wolve_coord , 1)
                if wolve in db['werewolves'] and str.startswith(order[1], '<') \
                        and (wolve not in used_wolves):
                    target_coord = get_entity_coord(str.strip(order[1][1:]))  # saut de 1 pour aller direct après le '<'
                    target_name = get_entity_name_on_coord(db['foods'], target_coord, 0)
                    if can_eat(target_coord, db['werewolves'][wolve][1]) and player == db['werewolves'][wolve][0]:
                        db = eat(wolve, target_name, db)
                        used_wolves.append(wolve)

    return db, used_wolves


def get_entity_coord(wolve):
    """get wolve coordinates from string

    Parameter:
    ---------
        wolve : 'y-x' encoding coord of entity from orders (str)

    Return:
    -------
        coord : coordonate of wolve (list[int])

    Versions:
    --------
        specification: Yannis Van Achter and Esteban Barracho (v.1 11/02/2022 -> v.2 16/03/22)
        implementation: Yannis Van Achter (v.1 11/02/2022)
    """
    logging.debug(f'wolve coord : {wolve}', stacklevel=logging.DEBUG)
    return [int(str.split(wolve, '-')[0]), int(str.split(wolve, '-')[1])]

def fight(db, orders, used_wolves):
    """Follow fight order and active fight function

    Parameters:
    -----------
        db : data base of game (dict)
        orders : List of all order (dict)
        used_wolves : list of used wolves (list)

    Return:
    -------
        copy: a copy of the database (dict)
        db : data base of game (dict)

    Versions:
    --------
        specification : Yannis Van Achter  and Esteban Barracho (v1. 27/02/2022 -> v.2 16/03/22)
        implementation : Yannis Van Achter (v2. 02/03/2022)
    """
    attacked = False
    for player in orders:
        for order in orders[player]:
            if order != '':
                order = str.split(order, ':')
                wolve_coord = get_entity_coord(str.strip(order[0]))
                wolve = get_entity_name_on_coord(db['werewolves'], wolve_coord, 1)
                if wolve in db['werewolves'] and str.startswith(order[1], '*') and (wolve not in used_wolves) \
                        and db['werewolves'][wolve][0] == player and db['werewolves'][wolve][2] > 0:
                    target_coord = get_entity_coord(str.strip(order[1][1:]))  # saut de 1 pour aller direct après le '*'
                    target_name = get_entity_name_on_coord(db['werewolves'], target_coord, 1)
                    if can_attack(target_coord, wolve_coord, db):
                        db = attack(wolve, target_name, db)
                        if db['werewolves'][target_name][2] <= 0:
                            db['werewolves'][target_name][2] = 0
                        used_wolves.append(wolve)
                        attacked = True

    return db, used_wolves, attacked


def can_move(new_coord, wolve, db):
    """autorise the wolve to move

    Parameters:
    -----------
        new_coord: [y,x] (list)
        wolve: name of wolve to move (str)
        db: data base of game (dict)

    Return:
    -------
        bool : True if wolve can move to his target, False otherwise

    Version:
    --------
        spécification: Yannis Van Achter (v1 16/02/2022)
        implémentation: Yannis Van Achter (v2 02/03/2022)
    """
    if new_coord[0] < 1 or new_coord[0] > db['map'][0]:
        return False
    if new_coord[1] < 1 or new_coord[1] > db['map'][1]:
        return False

    return can_eat(new_coord, db['werewolves'][wolve][1]) and (not wolve_on_place(db, new_coord))


def wolve_on_place(db, coord):
    """

    Parameters:
    -----------
        db : data base of game (dic)
        coord : coordonates of wolves (list)

    Return:
    ------
        True if wolve on case, False otherwise (bool)

    Versions:
    ---------
        spécification: Yannis Van Achter  and Esteban Barracho (v1 02/03/2022 -> v.2 16/03/22)
        implémentation: Yannis Van Achter (v1 02/03/2022)
    """
    for wolve in db['werewolves']:
        if coord == db['werewolves'][wolve][1]:
            return True
    return False


def can_eat(target_coord, wolve_coord):
    """autorise the wolve to eat

    Parameters:
    -----------
        target_coord: [y,x] (list)
        wolve_coord: [y,x] (list)

    Return:
    -------
        bool : True if wolve can eat his target, False otherwise

    Version:
    --------
        spécification: Yannis Van Achter (v1 16/02/2022)
        implémentation: Yannis Van Achter (v2 02/03/2022)
    """
    return (wolve_coord[0] - 1 <= target_coord[0] <= wolve_coord[0] + 1) \
           and (wolve_coord[1] - 1 <= target_coord[1] <= wolve_coord[1] + 1)


def can_attack(target_coord, wolve, db):
    """autorise the wolve to attack

    Parameters:
    -----------
        target_coord: [y,x] (list)
        wolve: [y,x] (list)
        db : data base of game (dic)

    Return:
    -------
        bool : True if wolve can attack his target, False otherwise

    Version:
    --------
        spécification: Yannis Van Achter (v1 16/02/2022)
        implémentation: Yannis Van Achter (v2 02/03/2022)
    """
    wolve_name = get_entity_name_on_coord(db['werewolves'], wolve, 1)
    if wolve_name == None:
        return False
    return can_eat(target_coord, wolve) and (not db['werewolves'][wolve_name][3])


def get_entity_name_on_coord(db, coord , index):
    """Get the key of entity from coordonates

    Parameters:
    -----------
        db : part of data base wich contain wath shoud be in (dict)
        coord : coordonate in y,x of wolve (list)
        index : index were coord should be (int)

    Return:
    -------
        entity: key associate to wolve of this coordonates (str)

    Versions:
    ---------
        spécification: Yannis Van Achter (v2 17/03/2022)
        implémentation: Yannis Van Achter (v2 17/03/2022)
    """
    for entity in db:
        if coord == db[entity][index]:
            return entity
