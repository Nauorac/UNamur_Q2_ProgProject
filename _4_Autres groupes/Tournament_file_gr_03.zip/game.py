"""Module providing Game main code for UNamur programmation project (INFOB132).

Other modules are used 

"""

__author__ = ["Esteban Barracho <esteban.barracho@student.unamur.be>", 
              "Yannis Van Achter <yannis.van.achter@student.unamur.be", ]
__date__   = "17 march 2022"
__version__= "v1.02.1"
__package__= ["AI.py", 
              "UI.py", 
              "data_manager", 
              "remote_player.py", 
              "utils.py", ]

# -- Modules --
import os.path as pt
import time 
import logging

from AI import *
from remote_player import *
from utils import *
from UI import *
from data_manager import *

# -- fonction --
def get_instructions(player):
    """ask for instructions to player

    Parameter:
    ----------
        player : player to input the instructions (str)

    Return:
    -------
        orders_list : 'y-x:oy-x' = coordonate of wolve: o = order , coordonate of action \
                Endoding order for game (list[str])

    Version:
    --------
        specification: Yannis Van Achter (v.1 11/02/2022)
        implementation: Yannis Van Achter (v.1 11/02/2022)
    """
    return input(format_string_for_UI(f'The player named : {player} can enter his order \n : '))


def get_distance(wolve1, wolve2):
    """Return the exact distance between 2 wolves as an absolute value

    Parameters:
    -----------
        wolve1 : [y,x] Coordonate of the first wolve (list[int])
        wolve2 : [y,x] Coordonate of the second wolve (list[int])

    Return:
    -------
        distance: the distance between wolves (int)

    Versions:
    --------
        spécification : Ghita Sahlal and Yannis Van Achter(v2 . 05/03/2022 -> v.3 16/03/22)
        implémentation : Ghita Sahlal and Yannis Van Achter (v2 . 05/03/2022)
    """
    return max(abs(wolve2[0] - wolve1[0]), abs(wolve2[1] - wolve1[1]))



def play_game(group_1, type_1, group_2, type_2):
    """Play a game.

    Parameters:
    ----------
        group_1: group of player 1 (int)
        type_1: type of player 1 (str)
        group_2: group of player 2 (int)
        type_2: type of player 2 (str)

    Note:
    ----
        Player type is either 'human', 'AI' or 'remote'.

        If there is an external referee, set group id to 0 for remote player.

    Versions:
    --------
        specification: Yannis Van Achter and Esteban Barracho (v.1 11/02/2022  -> v.2 16/03/22)
        implementation: Yannis Van Achter and Esteban Barracho (v.3 02/03/2022 -> v.4 16/03/22 -> V.5 28/03/2022)
    """
    # create connection between 2 computer if nessesary
    connection_1 = ''
    connection_2 = ''
    if type_1 == 'remote':
        try:
            connection_1 = create_connection(group_2, group_1)
        except (IOError, TypeError, NameError, ValueError, 
        EOFError, FileExistsError, FileNotFoundError) as error:
            exit(error)
    if type_2 == 'remote':
        try:
            connection_2 = create_connection(group_1, group_2)
        except (IOError, TypeError, NameError, ValueError, 
        EOFError, FileExistsError, FileNotFoundError) as error:
            exit(error)

    db = data_create()
    # create ui
    db_ui = {}
    order = {}
    db_ui['bord_back'] = creat_map(db)
    db_ui['moved_wolves'] = []
    db_ui['has_move'] = True
    update(db, db_ui['bord_back'], db_ui['has_move'], db_ui['moved_wolves'])
    game_round = 0
    while game_round <= 200:
        if type_1 == 'remote':
            order[1] = get_remote_orders(connection_1)
        elif type_1 == 'player':
            order[1] = get_instructions(group_1)
            update(db, db_ui['bord_back'], False, [])
        elif type_1 == 'IA':
            order[1], db = get_IA_order(db, 1)
        if type_2 == 'remote':
            notify_remote_orders(connection_2, order[1])
        order[1] = order[1].split(' ')
        
        logging.info(f'Order_1 : {order[1]}', stacklevel=logging.INFO)
        
        
        if type_2 == 'remote':
            order[2] = get_remote_orders(connection_2)
        elif type_2 == 'player':
            order[2] = get_instructions(group_2)
            update(db, db_ui['bord_back'], False, [])
        elif type_2 == 'IA':
            order[2], db = get_IA_order(db, 2, order[1])
        if type_1 == 'remote':
            notify_remote_orders(connection_1, order[2])
        order[2] = order[2].split(' ')
        time.sleep(0.3)
        
        logging.info(f'Order_2 : {order[2]}',stacklevel=logging.INFO)

        db, db_ui['has_move'], db_ui['moved_wolves'] , attacked = order_prosses(db, order)
        update(db, db_ui['bord_back'], db_ui['has_move'], db_ui['moved_wolves'])
        logging.info(f'DB {group_1}(1) VS {group_2}(2) : {db}', stacklevel=logging.WARNING)
        if attacked:
            game_round+=1
        game_over(db, type_1, type_2, connection_1 , connection_2)

    # if we didn't kill the oposite alpha in time we look for winner by adding the energy of each wolve 
    # the winner is set to the one who have the most energy
    energy_team = {1 : 0, 2: 0}
    for wolve , wolve_data in db['werewolves'].items():
        energy_team[wolve_data[0]] += wolve_data[2]
            
    clearConsole()
    untro()
    if type_1 == 'remote':
        close_connection(connection_1)
    if type_2 == 'remote':
        close_connection(connection_2)

    if energy_team[1] > energy_team[2]:
        exit(back.DARK_BLUE + fore.LIGHT_YELLOW + f'the winner is : The Team_BLUE' + style.RESET)
    elif energy_team[1] < energy_team[2]:
        exit(back.RED + fore.LIGHT_YELLOW + f'the winner is : The Team_RED' + style.RESET)
    else:
        exit(back.WHITE + fore.DARK_BLUE + f'the winner is : The Both of You' + style.RESET)

def game_over(db, type_1, type_2, connection_1 , connection_2):
    """This function stops the game and displays the winner of the game.
    Parameters:
    ----------
    db : data base of game (dict)
    type_1: type of player 1 (str)
    type_2: type of player 2 (str)
    connection_1 : socket(s) to receive/send orders (dict of socket.socket)
    connection_2 : socket(s) to receive/send orders (dict of socket.socket)

    Version:
    -------
    specification: Yannis Van Achter and Esteban Barracho (v.1 11/02/2022 -> v.2 16/03/22)
    implementation: Esteban Barracho and Yannis Van Achter(v.1 16/03/22)
    """
    num_str_list = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']
    winner = False

    # close connection, if necessary

    for name_wolf in db['werewolves']:
        if str.startswith(str(name_wolf).lower() , 'alpha') and db['werewolves'][name_wolf][2] == 0:
            winner = True
    if winner:
        clearConsole()
        for name_wolf in db['werewolves']:
            check_list = []
            checked = ''
            for lettre in name_wolf:
                check_list.append(lettre)
            for not_number in check_list:
                if not not_number in num_str_list:
                    checked += not_number
            if db['werewolves'][name_wolf][0] == 1 and db['werewolves'][name_wolf][2] == 0:
                winner = 'Team_RED'
                untro()
                if type_1 == 'remote':
                    close_connection(connection_1)
                if type_2 == 'remote':
                    close_connection(connection_2)
                exit(back.RED + fore.LIGHT_YELLOW + f'the winner is : The {winner}' + style.RESET)
            else:
                winner = 'Team_BLUE'
                untro()
                if type_1 == 'remote':
                    close_connection(connection_1)
                if type_2 == 'remote':
                    close_connection(connection_2)
                exit(back.DARK_BLUE + fore.LIGHT_YELLOW + f'the winner is : The {winner}' + style.RESET)
    return winner


# -- Code --
def get_int(*prompt):
    prompt = ''.join(map(str, prompt))
    while True:
        n = input(prompt)
        try:
            return int(n)
        except:
            pass
        
def get_type(*prompt):
    prompt = ''.join(map(str, prompt))
    type_ = 'AA'
    while type_ not in ('IA', 'remote', 'player'):
        type_ = input(prompt)
    return type_

if __name__ == '__main__':
    if input('Debug (y/n) : ').lower().startswith('y'):
        level = logging.DEBUG
        logging.basicConfig(level=level,
                        format='%(asctime)s, %(levelname)s : %(message)s')
    elif input('Info (y/n) : ').lower().startswith('y'):
        level = logging.INFO
        # here we want put all in a file because we add the data base which is realy big and hard to read
        logging.basicConfig(level=level,
                        filename='./data_base_upgrade.log',
                        filemode='w+',
                        format='%(asctime)s, %(levelname)s : %(message)s')
    else:
        level = 100 # noting will be print 
        logging.basicConfig(level=level,
                        format='%(asctime)s, %(levelname)s : %(message)s')
    type_player = ('IA', 'remote', 'player')
    while input('New game ? (y/n) : ').lower() == 'y':
    # map_path = './example.ano.txt' # input('Enter the map path (don\'t forget the \'./\') \n here: ')
        group_1 = int(input('Enter the n°  of the group : '))
        type_1 = input("Who play this game (player, IA, remote): ")
        group_2 = int(input('Enter the n°  of the group : '))
        type_2 = input("Who play this game (player, IA, remote): ")
        input('press enter to start game after placed the map in the current directory')
        if type_1 in type_player:
            if type_2 in type_player:
                try:
                    play_game(group_1, type_1, group_2, type_2)
                except (SystemError, SystemExit) as error:
                    print(error)
                    time.sleep(10)
            else:
                print('erreur type 2')
        else:
            print('erreur type 1')