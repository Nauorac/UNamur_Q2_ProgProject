"""Module providing AI features for UNamur programmation project (INFOB132).

Colored is used to show emoji

"""

__author__ = ["Esteban Barracho <esteban.barracho@student.unamur.be>", 
              "Yannis Van Achter <yannis.van.achter@student.unamur.be", ]
__date__   = "07 april 2022"
__version__= "v1.04.1"

# === Modules ===
import pickle as pkl, logging

from utils import *

# === Function ===
def get_IA_order(db, player, order = []):
    """get intelligent IA order

    Parameters:
    -----------
        db : data base of game (dict)
        player : 1 or 2 depending on who is played by IA (int)
        order : order of player 1 (list)

    Return:
    -------
        order_string : string of all order for each wolve (str)
        old_db : old data base of game (same as what was given) (dict)

    Version:
    --------
        specification : Yannis Van Achter (v1 23/03/2022)
        implementation : Yannis Van Achter and Esteban Barracho (v1 23/03/2022 -> v2 31/03/2022 -> v3 07/04/2022)
    """
    # here we store the old db in a file of the current repertory to avoid an error 
    # the error is that the db keep the same DataPath adress (function id() alow us to know) that in the current running file (game.py or engine_gr_3.py)
    # the effect is that by modify the db here we modify the db in the current running program.
    # By storing the db before modification we go back look for after the "reflection" to be sure that in current execution
    # the data base is not modified
    old_db = open("old_db.pickle", "wb")
    pkl.dump(db, old_db)
    old_db.close()
    
    if player == 2:
        orders = {1:order}
        used_wolves = []
        db, used_wolves = get_eat(db, orders, used_wolves)
        db, used_wolves, attacked = fight(db, orders, used_wolves)
        
    order_string = ''

    # init the loop for looking for orders
    wolve_own =  sorted([_ for _ in db['werewolves'] if db['werewolves'][_][0] == player])
    food_list = [_ for _ in db['foods'] if db['foods'][_][1] >= 40]
    can_find_order = True
    logging.debug(f'food_list : {food_list}', stacklevel=logging.INFO)
    
    # init the order for alpha wolve
    wolve_coord_alpha = [_ for wolve, _ in db['werewolves'].items() if wolve.lower().startswith('alpha') and _[0] == player][0][1]
    if len(food_list) > 0:
        food_to_protect = [_ for _ in nearest_correct_food(db['foods'], wolve_coord_alpha) if _ in food_list][0]
        food_list.remove(food_to_protect)
    else:
        food_to_protect = nearest_correct_food(db['foods'], wolve_coord_alpha)[0]
    
    while len(wolve_own) != 0 and can_find_order: # the while loop allow us to have the maximum of order 
        copy_wolve_own = wolve_own.copy()
        orders = {player : []} # we initialyse each time the order to avoid applying same order several times
        for wolve in copy_wolve_own:
            logging.debug(f'food_list : {food_list}', stacklevel=logging.INFO)
            if db['werewolves'][wolve][0] == player: # is this my wolve ??
                wolve_coord = db['werewolves'][wolve][1]
                if wolve.lower().startswith('alpha'):
                    # we want that alpha be on the nearest and most \
                    # important food source and any other wolve can
                    returned = scroched_earth(db, wolve, [food_to_protect], player,)
                    if returned != None:
                        if returned[0] != None and len(returned[0]) >= 4:
                            order_string += f'{wolve_coord[0]}-{wolve_coord[1]}' + returned[0]
                            orders[player].append((f'{wolve_coord[0]}-{wolve_coord[1]}' + returned[0]).strip())
                        wolve_own.remove(wolve)

                elif len(food_list) != 0:
                    returned = scroched_earth(db, wolve, food_list, player)
                    if returned != None:
                        if returned[0] != None and len(returned[0]) >= 4:
                            order_string += f'{wolve_coord[0]}-{wolve_coord[1]}' + returned[0]
                            orders[player].append((f'{wolve_coord[0]}-{wolve_coord[1]}' + returned[0]).strip())
                        wolve_own.remove(wolve)
                        if returned[1] != None:
                            food_list.remove(returned[1])
                            
                else:
                    returned = track_alpha(db , wolve, player)
                    if returned != None and len(returned) >= 4:
                        order_string += f'{wolve_coord[0]}-{wolve_coord[1]}' + returned
                        orders[player].append((f'{wolve_coord[0]}-{wolve_coord[1]}' + returned).strip())
                        wolve_own.remove(wolve)
        db = order_prosses(db, orders)[0]
        
        # find a maximum of order if we can not apply the first iteration  and the second we 'break' the loop
        if len(wolve_own) == len(copy_wolve_own):
            can_find_order = False

    old_db = open("old_db.pickle", "rb")
    db_old = pkl.load(old_db)
    old_db.close()
    return order_string.strip() , db_old


def get_entity_around(wolve_coord, db, index):
    """return the first entity around a wolve in the db

    Parameters:
    -----------
        wolve_coord : coord y,x of the entity on who we do research (list(int))
        db : part of database in which we do research (dict)
        index : index in db where coord should be (int)

    Return:
    -------
        list_volve : list of name of entity found (list(str))

    Version:
    --------
        specification : Yannis Van Achter (v1. 09/03/2022)
        implementation : Yannis Van Achter (v1. 09/03/2022)
    """
    list_entity = []
    for entity in db:
        target_coord = db[entity][index]
        if can_eat(target_coord, wolve_coord):
            list_entity.append(entity)
    return list_entity

def get_direction(target , wolve, _db_):
    """get next positon to go at gived coord

    To call this function pass in parameter the target, wolve and db 

    Parameters:
    -----------
        target : coord where to go (list)
        wolve : coord of wolve to move (list)
        _db_ : database of game (dict)

    Returns:
    --------
        next position : coord of where the wolve will go (list)
        
    Version:
    --------
        specification : Yannis Van Achter (v1 23/03/04)
        implementation : Yannis Van Achter (v1 23/03/04 -> v2 19/04/2022 -> v3 21/04/2022)
    """
    db = _db_.copy()
    logging.debug(f'In get_direction : target={target}, wolve={wolve}, and db', stacklevel=logging.DEBUG)
        
    direction = basic_direction(target, wolve)
    wolve_name = get_entity_name_on_coord(db['werewolves'], wolve, 1)
    if wolve_name != None and not can_move(direction, wolve_name, db): # compute the best possibility to move if we can not take the fastest way
        directions = {}
        for y in range(wolve[0]-1, wolve[0]+2):
            for x in range(wolve[1]-1, wolve[1]+2):
                if [y,x] !=wolve and can_move([y,x], wolve_name, db):
                    new_dist = get_distance([y,x], target)
                    directions[new_dist] = [y,x]
        logging.debug(f'directions : {directions}', stacklevel=logging.DEBUG)
        if len(directions) != 0:
            direction = directions[min(list(directions.keys()))] # get coord to go by the minimum distance from wolve to target
    if direction == None:
        logging.debug(f'direction : {direction}', stacklevel=logging.DEBUG)
        return basic_direction(target, wolve)
    logging.debug(f'direction : {direction}', stacklevel=logging.DEBUG)
    return direction # return the fastest directions

def basic_direction(target, wolve):
    """Get basic direction for a wolve

    Based on delta between two wolves should not be call out of get_direction function

    Parameters:
    -----------
        target (list): coord of destination
        wolve (list): coord of wolve wich have to move

    Returns:
    --------
        list: next position for the wolve
        
    Version:
    --------
        specification: Yannis Van Achter (v1 23/03/2022)
        implementation: Yannis Van Achter (v1 23/03/2022)
    """
    if can_eat(target , wolve):
        return target
    
    direction = wolve.copy() # use copy method to change the addres in memory and unlink the variables
    
    delta_x = target[1] - wolve[1]
    delta_y = target[0] - wolve[0]
    
    direction[0] += 1 if delta_y > 0 else (-1 if delta_y < 0 else 0)
    direction[1] += 1 if delta_x > 0 else (-1 if delta_x < 0 else 0)
    
    return direction

def nearest_correct_food(db , wolve):
    """return list of wolve with enough energy shorted by energy follow by distance

    Parameters:
    -----------
        db : data base of game (dict)
        wolve : coord of wolve in process (list)

    Returns:
    --------
        food list : list of food sorted by distance and a minimum of energy (list)
        
    Version:
    --------
        specification : Yannis Van Achter (v1 23/03/04)
        implementation : Yannis Van Achter (v1 23/03/04 -> v2 06/04/2022)
    """
    food_list = list(db.keys()) # tranfor the set return by dict.keys() method to a list
    
    # remove food wich don't have enough energy
    poped = True
    while poped:
        poped = False
        for food in food_list:
            if db[food][1] < 10 and not poped:
                food_list.remove(food)
                poped = True
    
    # short list by energy
    moved = True
    while moved:
        moved = False
        for food_id in range(1, len(food_list)):
            if db[food_list[food_id-1]][1] < db[food_list[food_id]][1]:
                moved = True
                food_list[food_id-1], food_list[food_id] = food_list[food_id], food_list[food_id-1] # swap
    
    # short list by distance
    moved = True
    while moved:
        moved = False
        for food_id in range(1, len(food_list)):
            if get_distance(wolve , db[food_list[food_id-1]][0]) > get_distance(wolve, db[food_list[food_id]][0]):
                moved = True
                food_list[food_id-1], food_list[food_id] = food_list[food_id], food_list[food_id-1] # swap
                
    return food_list
        

def track_alpha(db , wolve , player):
    """get order for this wolve if we apply the huntinf of alpha strategy

    Parameters:
    -----------
        db : data base of game (dict)
        wolve : name of wolve in process (str)
        player : number of player we are (int)

    Returns:
    --------
        order : order apply to this wolve (str)
        
    Version:
    --------
        specification : Yannis Van Achter (v1 23/03/04)
        implementation : Yannis Van Achter (v1 23/03/04)
    """
    logging.debug('In track alpha', stacklevel=logging.DEBUG)
    wolve_data = db['werewolves'][wolve]
    logging.debug(f'wolve_data : {wolve_data}', stacklevel=logging.DEBUG)
    wolve_coord = wolve_data[1]
    logging.debug(f'wolve_coord : {wolve_coord}', stacklevel=logging.DEBUG)
    enemy_wolves = [_ for _ in db['werewolves'] if db['werewolves'][_][0] != player] # list of enemy wolves
    alpha_name = [wolf for wolf in enemy_wolves if str.startswith(wolf.lower(), 'alpha')][0] # get name of alpha
    alpha_coord = db['werewolves'][alpha_name][1]
    
    if  wolve_data[2] > 5:
        alpha_path = get_direction(alpha_coord,  wolve_coord, db)
        if can_attack(alpha_coord , wolve_coord, db):
            return f":*{alpha_coord[0]}-{alpha_coord[1]} "
        elif wolve_on_place(db, alpha_path) and can_attack(alpha_path, wolve_coord, db) \
            and db['werewolves'][get_entity_name_on_coord(db['werewolves'] , alpha_path, 1)][0] != player:
            return f":*{alpha_path[0]}-{alpha_path[1]} "
        else:
            wolve_around = get_entity_around(wolve_coord, db['werewolves'], 1)
            if len(wolve_around) == 1 and db['werewolves'][wolve_around[0]][0] != player:
                target_coord = db['werewolves'][wolve_around[0]][1]
                return f":*{target_coord[0]}-{target_coord[1]} "
            else:
                # get most dangerous
                most_dangerous = ''
                max_energy = 0
                for enemy in wolve_around:
                    if db['werewolves'][enemy][2] > max_energy and db['werewolves'][enemy][0] != player:
                        most_dangerous = enemy
                        max_energy = db['werewolves'][enemy][2]
                
                if most_dangerous != '': # there is a wolve arround wich is not ours
                    most_dangerous_coord = db['werewolves'][most_dangerous][1]
                    return f":*{most_dangerous_coord[0]}-{most_dangerous_coord[1]} " 
                
                else:
                    if can_move(alpha_path , wolve , db):
                        return f":@{alpha_path[0]}-{alpha_path[1]} "
    else:
        food_target_coord = nearest_correct_food(db['foods'], wolve_coord)
        if len(food_target_coord) >= 1:
            food_target_coord = db['foods'][food_target_coord[0]][0]
            if not can_eat(food_target_coord, wolve_coord):
                food_target_coord = get_direction(food_target_coord, wolve_coord, db)
            return f":<{food_target_coord[0]}-{food_target_coord[1]} "
        else:
            alpha_own = [_ for _ in db['werewolves'] if str.startswith(_.lower() , 'alpha') and db['werewolves'][_][0] == player][0]
            alpha_shield = get_direction(db['werewolves'][alpha_own][1], wolve_coord, db)
            if get_distance(wolve_coord, alpha_shield) > 1:
                return f":@{alpha_shield[0]}-{alpha_shield[1]} "
        
def scroched_earth(db, wolve_name, food_list, player):
    """Apply scroched earth strategy 

    Parameters:
    ----------
        db : data base of game (dict)
        wolve_name : wolve we look for order (str)
        food_list : list of food to protect (list[str])
        player : player we are (int[1 or 2])

    Returns:
    -------
        Order : order to apply at this wolve (str or NoneType)
        protected_food : food which have a protector (str or NoneType) 
        
    Notes:
    ------
        if food return is 'None' it means that we arent protect a food because we do something more important
        if not required the order is 'None' because the wolve already protect a food (he is at the same place of food)
        
    Version:
    --------
        spécification: Yannis Van Achter (v1. 05/04/2022)
        implementation: Yannis Van Achter (v1. 05/04/2022 -> v2. 06/04/2022)
    """
    wolve_data = db['werewolves'][wolve_name]
    wolve_coord = wolve_data[1]
    
    # we will look if alpha enemy can be attack
    alpha_enemy_coord = [_ for wolve_name, _ in db['werewolves'].items() if wolve_name.lower().startswith('alpha') and _[0] != player][0][1] # the list in comprehention get alpha enemy coord
    
    # create a special dict with food we want to protect only
    food_data_list = [_ for food, _  in db['foods'].items() if food in food_list]
    food = dict(zip(food_list, food_data_list)) # use the dict object to transform the tuple return by zip object into a dict
    
    # we use this function to short the food by distance
    food_list = nearest_correct_food(food, wolve_coord) # we have to do it after the creation of dict 
    # to keep the same index between food_name and his associated data
    
    for food_name in food_list:
        food_data = food[food_name]
        food_coord = food_data[0]
        
        if wolve_coord == food_coord and wolve_data[2] <= 99 and food_data[1] >= 10:
            return f':<{food_coord[0]}-{food_coord[1]} ', food_name
        elif can_attack(alpha_enemy_coord, wolve_coord, db):
            return f':*{alpha_enemy_coord[0]}-{alpha_enemy_coord[1]} ' , None
        elif wolve_coord == food_coord:
            # we already protect a food
            wolve_around = get_entity_around(wolve_coord, db['werewolves'], 1)
            if len(wolve_around) == 1 and db['werewolves'][wolve_around[0]][0] != player:
                target_coord = db['werewolves'][wolve_around[0]][1]
                return f":*{target_coord[0]}-{target_coord[1]} ", food_name
            
            # get most dangerous
            most_dangerous= ''
            max_energy = 0
            for enemy in wolve_around:
                if ((db['werewolves'][enemy][2] > max_energy and \
                    (not (enemy.lower()).startswith('alpha'))) or ((enemy.lower()).startswith('alpha'))) \
                        and db['werewolves'][enemy][0] != player:
                    most_dangerous = enemy
                    max_energy = db['werewolves'][enemy][2]
            
            if most_dangerous != '':
                most_dangerous_coord = db['werewolves'][most_dangerous][1]
                return f":*{most_dangerous_coord[0]}-{most_dangerous_coord[1]} " , food_name
            return None, food_name
        
        food_path = get_direction(food_coord , wolve_coord, db)
        if wolve_on_place(db, food_path) and db['werewolves'][get_entity_name_on_coord(db['werewolves'], food_path, 1)][0] != player \
            and can_attack(food_path, wolve_coord, db):
            return f":*{food_path[0]}-{food_path[1]} " , food_name
        elif can_move(food_path, wolve_name, db):
            return f":@{food_path[0]}-{food_path[1]} " , food_name
        


if __name__=='__main__':
    if input('Debug (y/n) : ').lower().startswith('y'):
        level = logging.DEBUG
    else:
        level = logging.ERROR
    logging.basicConfig(level=level,
                        format='%(asctime)s, %(levelname)s : %(message)s')
    db = {'map': [21, 21], 
          'werewolves': {'alpha7970': [1, [11, 10], 100, False, 0], 
                         'omega2402': [1, [1, 1], 100, False, 0], 
                         'normal8274': [1, [1, 2], 100, False, 0], 
                         'normal5144': [1, [2, 1], 100, False, 0], 
                         'normal7065': [1, [1, 3], 100, False, 0],
                         'normal9791': [1, [2, 3], 100, False, 0],
                         'normal4614': [1, [3, 3], 100, False, 0], 
                         'normal1419': [1, [3, 2], 100, False, 0], 
                         'normal6429': [1, [3, 1], 100, False, 0], 
                         'alpha2816': [2, [10, 11], 100, False, 0], 
                         'omega6045': [2, [20, 20], 100, False, 0], 
                         'normal2741': [2, [20, 19], 100, False, 0],
                         'normal8570': [2, [19, 20], 100, False, 0], 
                         'normal1822': [2, [20, 18], 100, False, 0], 
                         'normal622': [2, [19, 18], 100, False, 0], 
                         'normal9318': [2, [18, 18], 100, False, 0],
                         'normal4074': [2, [18, 19], 100, False, 0], 
                         'normal8562': [2, [18, 20], 100, False, 0]}, 
          'foods': {'berries3235': [[4, 4], 10], 
                    'berries7928': [[4, 5], 10], 
                    'berries5694': [[5, 4], 10], 
                    'berries5651': [[5, 5], 10], 
                    'berries2007': [[16, 16], 10], 
                    'berries1261': [[16, 17], 10], 
                    'berries8058': [[17, 16], 10], 
                    'berries9707': [[17, 17], 10], 
                    'apples5390': [[1, 4], 30], 
                    'apples8209': [[1, 5], 30], 
                    'apples660': [[20, 16], 30],
                    'apples9512': [[20, 17], 30], 
                    'mice837': [[4, 1], 50], 
                    'mice9236': [[5, 1], 50],
                    'mice2146': [[16, 20], 50],
                    'mice9945': [[17, 20], 50],
                    'rabbits4496': [[5, 7], 100], 
                    'deers3367': [[7, 5], 500],
                    'rabbits2749': [[16, 14], 100], 
                    'deers887': [[14, 16], 500]}}
    enemy = [_ for _ in db['werewolves'] if db['werewolves'][_][0] != 1]
    
    wolve_coord = [_ for wolve, _ in db['werewolves'].items() if wolve.lower().startswith('alpha') and _[0] == 1][0][1]
    print(wolve_coord)
    