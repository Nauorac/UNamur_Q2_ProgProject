#-*- coding: utf-8 -*-

"""
██████╗ ██╗   ██╗     ██████╗ ██████╗  ██████╗ ██╗   ██╗██████╗ ███████╗    ██████╗ ███████╗
██╔══██╗╚██╗ ██╔╝    ██╔════╝ ██╔══██╗██╔═══██╗██║   ██║██╔══██╗██╔════╝    ╚════██╗╚════██║
██████╔╝ ╚████╔╝     ██║  ███╗██████╔╝██║   ██║██║   ██║██████╔╝█████╗       █████╔╝    ██╔╝
██╔══██╗  ╚██╔╝      ██║   ██║██╔══██╗██║   ██║██║   ██║██╔═══╝ ██╔══╝      ██╔═══╝    ██╔╝ 
██████╔╝   ██║       ╚██████╔╝██║  ██║╚██████╔╝╚██████╔╝██║     ███████╗    ███████╗   ██║  
╚═════╝    ╚═╝        ╚═════╝ ╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚═╝     ╚══════╝    ╚══════╝   ╚═╝
"""

import random

def get_AI_orders(board, team, alpha_positions, omega_positions):
    """Get the orders of the AI

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    team: The team of the AI (int)
    alpha_positions: The positions of the alphas (dict)
    omega_positions: The positions of the omegas (dict)

    Returns
    -------
    orders: The orders of the AI (str)

    Version
    -------
    specification: Martin Devolder (v.3 13/03/22)
    implementation: Nicolas Collignon, Martin Devolder, Gabriel Gofflot, Philippe Hennericy (v.4 30/04/22)
    """

    # Definitions of some utility sub-functions
    def get_distance(first_position, second_position):
        """Get the distance between two points
        
        Parameters
        ----------
        first_position: coordinates of the first position (tuple)
        second_position: coordinates of the second positon (tuple)
        
        Returns
        -------
        distance: Calculated distance (int)
        """

        # Spliting the coordinates
        first_position_row = first_position[0]
        first_position_column = first_position[1]

        second_position_row = second_position[0]
        second_position_column = second_position[1]

        # Calculating the distance between the two points and return it
        return max(abs(second_position_row - first_position_row), abs(second_position_column - first_position_column))

    def go_to_target(board, wolf, target, reverse = False):
        """Finds the best move to go to the target

        Parameters
        ----------
        board: The data structure that contains the map (dict)
        wolf: The wolf to move (tuple)
        target: The target to go to (tuple)
        reverse (optional): If the wolf has to go to the target or the opposite (bool)

        Returns
        -------
        x_move: The x move to do (int)
        y_move: The y move to do (int)
        """

        # Calculate the way to follow
        if target[0] > wolf[0]:
            x_move = 1
        elif target[0] < wolf[0]:
            x_move = -1
        else:
            x_move = 0
        if target[1] > wolf[1]:
            y_move = 1
        elif target[1] < wolf[1]:
            y_move = -1
        else:
            y_move = 0
        
        if reverse:
            x_move = -x_move
            y_move = -y_move
        
        # If a wolf is on the way, we try to find another way
        attempts = 0
        while (wolf[0] + x_move, wolf[1] + y_move) in board['werewolves'] and attempts < 15:
            x_move = random.randint(-1, 1)
            y_move = random.randint(-1, 1)
            attempts += 1

        # Return the moves to do    
        return x_move, y_move
    
    def find_nearest_food(board, wolf):
        """Find the nearest food to the wolf

        Parameters
        ----------
        board: The data structure that contains the map (dict)
        wolf: The wolf who need eat (tuple)

        Returns
        -------
        nearest_food: The nearest food (tuple)
        """
        
        best_food = None
        best_energy = 0
        for food in board['foods']:
            if get_distance(wolf, food) <= 1 and board['foods'][food][1] > best_energy:
                best_food = food
                best_energy = board['foods'][food][1]
        return best_food

    # Creation of the string that will contain the orders
    orders = ''

    # Filling two lists with the wolves of each team
    AI_wolves = []
    other_wolves = []
    for wolf in board['werewolves']:
        if board['werewolves'][wolf]['team'] == team:
            AI_wolves.append(wolf)
        else:
            other_wolves.append(wolf)
    
    # Tracking the alpha enemy
    if team == 1:
        enemy_alpha = alpha_positions[2]
    else:
        enemy_alpha = alpha_positions[1]
    
    # Iteration on the AI wolves to find the an order for each of them
    for wolf in AI_wolves:
        order_done = False
        wolf_energy = board['werewolves'][wolf]['energy']
        wolf_type = board['werewolves'][wolf]['type']
        food = find_nearest_food(board, wolf)

        # Iteration on the other wolves to find a wolf to attack
        for other_wolf in other_wolves:
            _distance = get_distance(wolf, other_wolf)

            # If the wolf is an alpha and a wolf is close enough, we escape
            if _distance == 1 and wolf_type == 'alpha' and board['werewolves'][other_wolf]['pacific'] == False and not order_done:
                x_move, y_move = go_to_target(board, wolf, other_wolf, reverse = True)
                orders += '%d-%d:@%d-%d ' % (wolf[0], wolf[1], wolf[0] + x_move, wolf[1] + y_move)
                order_done = True

            # If no order is found and the wolf isn't an alpha and a wolf is close enough, we attack
            elif _distance == 1 and wolf_energy > 0 and not board['werewolves'][wolf]['pacific'] and board['werewolves'][other_wolf]['energy'] > 0 and not order_done:
                orders += '%d-%d:*%d-%d ' % (wolf[0], wolf[1], other_wolf[0], other_wolf[1])
                order_done = True
        
        # If no order is found and the wolf has no energy left, it tries to eat. If he can't find food, he goes near his alpha
        if wolf_energy == 0 and wolf_type != 'alpha' and not order_done:
            if food:
                orders += '%d-%d:<%d-%d ' % (wolf[0], wolf[1], food[0], food[1])
            else:
                x_move, y_move = go_to_target(board, wolf, alpha_positions[team])
                orders += '%d-%d:@%d-%d ' % (wolf[0], wolf[1], wolf[0] + x_move, wolf[1] + y_move)

        # If no order is found and the omega sees a wolf within pacification range, it throws it
        elif _distance <= 6 and wolf == omega_positions[team] and wolf_energy > 40 and not order_done:
            orders += '%d-%d:pacify ' % (wolf[0], wolf[1])

        # If no order is found and there is food nearby and the wolf needs to regain life, it eats
        elif food and wolf_energy < 100 and not order_done:
            orders += '%d-%d:<%d-%d ' % (wolf[0], wolf[1], food[0], food[1])

        # If no order is found and the wolf is not alpha, it goes to the opposite alpha
        elif wolf_type != 'alpha' and not order_done:
            x_move, y_move = go_to_target(board, wolf, enemy_alpha)
            orders += '%d-%d:@%d-%d ' % (wolf[0], wolf[1], wolf[0] + x_move, wolf[1] + y_move)
        
        # If no order is found and the wolf is alpha, it goes behind its omega
        elif not order_done:
            x_move, y_move = go_to_target(board, wolf, omega_positions[team])
            orders += '%d-%d:@%d-%d ' % (wolf[0], wolf[1], wolf[0] + x_move, wolf[1] + y_move)
        
    # Return the orders for each wolf of the AI team
    return orders.strip()