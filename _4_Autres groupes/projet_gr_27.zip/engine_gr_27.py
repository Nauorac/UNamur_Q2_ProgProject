#-*- coding: utf-8 -*-

"""
██████╗ ██╗   ██╗     ██████╗ ██████╗  ██████╗ ██╗   ██╗██████╗ ███████╗    ██████╗ ███████╗
██╔══██╗╚██╗ ██╔╝    ██╔════╝ ██╔══██╗██╔═══██╗██║   ██║██╔══██╗██╔════╝    ╚════██╗╚════██║
██████╔╝ ╚████╔╝     ██║  ███╗██████╔╝██║   ██║██║   ██║██████╔╝█████╗       █████╔╝    ██╔╝
██╔══██╗  ╚██╔╝      ██║   ██║██╔══██╗██║   ██║██║   ██║██╔═══╝ ██╔══╝      ██╔═══╝    ██╔╝ 
██████╔╝   ██║       ╚██████╔╝██║  ██║╚██████╔╝╚██████╔╝██║     ███████╗    ███████╗   ██║  
╚═════╝    ╚═╝        ╚═════╝ ╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚═╝     ╚══════╝    ╚══════╝   ╚═╝
"""

import blessed, time
from AI_gr_27 import get_AI_orders
from remote_play import create_connection, get_remote_orders, notify_remote_orders, close_connection
term = blessed.Terminal()



# Other functions
def read_config(path_file):
    """Reads the configuration file and stores it in a data structure

    Parameters
    ----------
    path_file: The path to the configuration file (str)

    Returns
    -------
    board: The data structure that contains the map (dict)
    alpha_positions: The positions of the alpha wolves (dict)
    omega_positions: The positions of the omega wolves (dict)

    Version
    -------
    specification: Philippe Hennericy (v.2 06/03/22)
    implementation: Martin Devolder (v.2 06/03/22)
    """

    # Creation of the data structure that will contain the configuration and the positions of alpha and omega wolves
    board = {}
    alpha_positions = {}
    omega_positions = {}

    # Opening the configuration file and creating a var too know in what section we are
    file = open(path_file, "r")
    current_section = ""

    # Reading the file line by line
    for line in file.readlines():

        # Removing the \n at the end of the line
        line = line.strip('\n')

        # If the line is a section, we change the current section
        if line.endswith(':'):
            current_section = line.strip(':')
            if current_section == 'werewolves':
                board[current_section] = {}
            elif current_section == 'foods':
                board[current_section] = {}

        # If the line is not a section, we add the parsed line to the current section
        elif current_section == 'map':
            split_line = line.split()
            x_size = int(split_line[0])
            y_size = int(split_line[1])
            board[current_section] = (x_size, y_size)
        elif current_section == 'werewolves':
            split_line = line.split()
            wolf_team = int(split_line[0])
            x_position = int(split_line[1])
            y_position = int(split_line[2])
            werewolf_type = split_line[3]

            # If the wolf is a alpha or a omega, we add it to the corresponding list
            if werewolf_type == 'alpha':
                alpha_positions[wolf_team] = (x_position, y_position)
            elif werewolf_type == 'omega':
                omega_positions[wolf_team] = (x_position, y_position)

            board[current_section][(x_position, y_position)] = {'team': wolf_team, 'type': werewolf_type, 'pacific': False, 'energy': 100, 'bonus': 0}
        
        elif current_section == 'foods':
            split_line = line.split()
            x_position = int(split_line[0])
            y_position = int(split_line[1])
            food_type = split_line[2]
            energic_content = int(split_line[3])
            board[current_section][(x_position, y_position)] = [food_type, energic_content]
    
    # Closing the file and returning the data structure
    file.close()
    return board, alpha_positions, omega_positions

def convert_coordinates(row, column):
    """Find coordinates on the terminal from coordinates on the map

    Parameters
    ----------
    row: The row position on the map (int)
    column: The column position on the map (int)

    Returns
    -------
    row: The row position on the terminal (int)
    column: The column position on the terminal (int)

    Version
    -------
    specification: Gabriel Gofflot (v.1 13/03/22)
    implementation: Martin Devolder (v.1 13/03/22)
    """

    row =  (row * 2) + 2
    column = (column * 4) + 23
    return row, column

def display_map(board):
    """Displays the map with a data struct
    
    Parameters
    ----------
    board: The data structure that contains the map (dict)

    Version
    -------
    specification: Nicolas Collignon (v.2 11/03/22)
    implementation: Nicolas Collignon (v.2 11/03/22)
    """

    # Definition of one sub-function
    def insert_number(number, line, row):
        """Inserts numbers in row 0 and column 0

        Parameters
        ----------
        number: The x or y position of the box (int)
        line: The line to modify (str)
        row: The row position (int)

        Returns
        -------
        line: The line with the number (str)
        """
        if len(str(number)) == 1:
            box = '│ %d ' % number
        else:
            box = '│ %d' % number
        line = line[:(4 * row)] + box + line[4 * (row + 1):]
        return line

    # Clearing the terminal
    print(term.clear)

    # Definition of the board characters
    vertical_line = "│"
    horizontal_line = "─"
    lower_left_corner = "└"
    upper_left_corner = "┌"
    lower_right_corner = "┘"
    upper_right_corner = "┐"
    top_tee = "┬"
    bottom_tee = "┴"
    left_tee = "├"
    right_tee = "┤"
    central_plus = "┼"

    # Construction and printing of the top of the grid
    top_board = upper_left_corner + ((horizontal_line * 3) + top_tee) * (board['map'][0]) + (horizontal_line * 3) + upper_right_corner
    print(term.hide_cursor + term.on_green(' ' * 7, 'TEAM 1', ' ' * 7), top_board)

    # Iteration on the lines of the grid
    for column in range(board['map'][1] + 1):

        # Construction of the line without the objects on the map
        mid_board = left_tee + (board['map'][0] * ((horizontal_line * 3) + central_plus)) + (horizontal_line * 3) + right_tee
        line = (vertical_line + '   ') * (board['map'][0] + 1) + vertical_line
        
        for row in range(board['map'][0] + 1):

            # Inserting of numbers in row 0 and column 0
            if column == 0:
                line = insert_number(row, line, row)
            elif row == 0:
                line = insert_number(column, line, row)

        # Printing of the line with wolf informations on the side
        if column == 0:
            side = term.on_green('-' * 20)
        elif column < board['map'][1] // 2:
            side = term.on_green(' ' * 20)
        elif column == (board['map'][1] // 2) + 1:
            side = term.on_blue('-' * 20)
        else:
            side = term.on_blue(' ' * 20)
        print(side, line)

        if column == board['map'][1] // 2:
            print(term.on_blue(' ' * 7, 'TEAM 2', ' ' * 7), mid_board)
        elif column == (board['map'][1] // 2) - 1:
            print(term.on_green('-' * 20), mid_board)
        elif column < board['map'][1] // 2:
            print(term.on_green(' ' * 20), mid_board)
        elif column != board['map'][1]:
            print(term.on_blue(' ' * 20), mid_board)

    # Construction and printing of the bottom of the grid
    bottom_board = lower_left_corner + board['map'][0] * ((horizontal_line * 3) + bottom_tee) + (horizontal_line * 3) + lower_right_corner
    print(term.on_blue('-' * 20), bottom_board)

    # Printing an color explanation
    x_position = (27) + (4 * board['map'][0])
    print(term.move_xy(x_position, 1) + term.on_red('Attacked'))
    print(term.move_xy(x_position, 2) + term.on_purple('Pacific or human'))
    print(term.move_xy(x_position, 3) + term.on_orange('Being eaten'))

def display_update(board, map_symbols, round):
    """Displays the objects on the map and on the side at each turn

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    map_symbols: The data structure that contains the symbols of the map (dict)
    round: The number of the round (int)

    Version
    -------
    specification: Martin Devolder (v.3 18/03/22)
    implementation: Martin Devolder (v.3 18/03/22)
    """

    # Definition of two sub-functions
    def build_side(board, team, werewolves, map_symbols):
        """Build a side of the map with werewolves informations and print it

        Parameters
        ----------
        board: The data structure that contains the map (dict)
        team: The team of the werewolves to display (int)
        werewolves: The werewolves of the team (list)
        map_symbols: The symbols of the map (dict)
        """
        
        for wolf in werewolves:
            energy = board['werewolves'][wolf]['energy']
            werewolf_type = board['werewolves'][wolf]['type']
            side = '%s, %d, %s' % (wolf, energy, map_symbols[werewolf_type])
            side = ' ' * ((20 - len(side)) // 2) + side + ' ' * ((20 - len(side)) // 2)
            if len(side) < 20:
                side += ' ' * (20 - len(side))
            if team == 1:
                print(term.on_green(side))
            else:
                print(term.on_blue(side))
            
            # If there are more wolves in a team than the size of the card divided by 2, we remove the aesthetic line jumps to have more space
            if len(werewolves) < board['map'][1] // 2:
                print()
    
    def find_colorization(team, pacific):
        """Find the colorization of a box
        
        Parameters
        ----------
        team: The team of the werewolves to display (int)
        pacific: A boolean that indicates if an eventual wolf in the box is a pacific or not (bool)
        
        Returns
        -------
        colorization: The colorization function for the box (func)
        wolf_colorization: The colorization function for the werewolf of the box (func)
        """
        
        if team == 1:
            colorization = term.on_green
            wolf_colorization = term.on_green
        elif team == 2:
            colorization = term.on_blue
            wolf_colorization = term.on_blue
        if pacific:
            wolf_colorization = term.on_purple
        return colorization, wolf_colorization
    
    # Displaying the current turn
    print(term.move_xy(22, 1) + term.red('Round %d' % round))

    # Iteration on the objects on the map
    for row in range(1, board['map'][0] + 1):
        for column in range(1, board['map'][1] + 1):

            if (row, column) in board['werewolves'] and (row, column) in board['foods']:
                # Inserting a wolf and a food on the map
                wolf = board['werewolves'][(row, column)]
                wolf_type = wolf['type']
                wolf_team = wolf['team']
                pacific = wolf['pacific']
                food = board['foods'][(row, column)][0]
                row_position, column_position = convert_coordinates(row, column)
                colorization, wolf_colorization = find_colorization(wolf_team, pacific)
                print(term.move_yx(row_position, column_position - 1) + wolf_colorization(map_symbols[wolf_type]) + colorization(' ' + map_symbols[food]))
            elif (row, column) in board['werewolves']:
                # Inserting of the wolf on the map
                wolf = board['werewolves'][(row, column)]
                wolf_type = wolf['type']
                wolf_team = wolf['team']
                pacific = wolf['pacific']
                row_position, column_position = convert_coordinates(row, column)
                colorization, wolf_colorization = find_colorization(wolf_team, pacific)
                print(term.move_yx(row_position, column_position - 1) + colorization(' ') + wolf_colorization(map_symbols[wolf_type]) + colorization(' '))
            elif (row, column) in board['foods']:
                # Inserting of the food on the map
                food = board['foods'][(row, column)]
                food_type = food[0]
                row_position, column_position = convert_coordinates(row, column)
                print(term.move_yx(row_position, column_position - 1) + ' ' + map_symbols[food_type] + ' ')
            else:
                # Inserting of the empty space on the map if there is no object
                row_position, column_position = convert_coordinates(row, column)
                print(term.move_yx(row_position, column_position - 1) + ' ' * 3)

    # Filling lists of werewolves by team
    team_1_wolves = []
    team_2_wolves = []
    for wolf in board['werewolves']:
        if board['werewolves'][wolf]['team'] == 1:
            team_1_wolves.append(wolf)
        elif board['werewolves'][wolf]['team'] == 2:
            team_2_wolves.append(wolf)
    
    # Displaying wolves informations on the side of the map (The size of the information for each team varies according to the size of the tray)
    print(term.move_xy(0, 3))
    build_side(board, 1, team_1_wolves, map_symbols)

    if board['map'][1] % 2 == 0:
        second_informations_position_y =  board['map'][1] + 5
    else:
        second_informations_position_y = board['map'][1] + 4

    print(term.move_xy(0, second_informations_position_y))
    build_side(board, 2, team_2_wolves, map_symbols)

def display_action(board, map_symbols, target, action, team = None, inversion = True):
    """Displays the actions of the werewolves

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    map_symbols: The data structure that contains the symbols of the map (dict)
    target: The target box of the action (tuple)
    action: The action to display (str)
    team (optional): The team of the werewolf who do the action (int)
    inversion (optional): If the color of the teams are inversed (bool)

    Version
    -------
    specification: Martin Devolder (v.1 13/03/22)
    implementation: Martin Devolder (v.2 14/03/22)
    """

    # Definition of one sub-function
    def on_normal(text):
        """Set a text with normal background color

        Parameters
        ----------
        text: The text to set (str)

        Returns
        -------
        The text with normal background color (str)
        """

        return term.normal + text

    # Finding team of the werewolf who is on the target box if it is not given
    if not team and target in board['werewolves'] and target in board['foods']:
        team = board['werewolves'][target]['team']
        target_type = board['werewolves'][target]['type']

    # Finding the position of the target box
    row_position, column_position = convert_coordinates(*target)

    # Choosing the color of the differents parts of the box
    food_colorization = on_normal
    if action == 'attack':
        target_type = board['werewolves'][target]['type']
        colorization = term.on_red
    elif action == 'pacify':
        target_type = board['werewolves'][target]['type']
        colorization = term.on_purple
    elif action == 'eat':
        colorization = on_normal
        food_colorization = term.on_orange
    
    if (team == 1 and inversion) or (team == 2 and not inversion):
        team_colorization = term.on_blue
        if action != 'eat':
            food_colorization = term.on_blue
    elif (team == 2 and inversion) or (team == 1 and not inversion):
        team_colorization = term.on_green
        if action != 'eat':
            food_colorization = term.on_green
    else:
        team_colorization = on_normal
    
    # Displaying the action
    if target in board['werewolves'] and target in board['foods']:
        if colorization == on_normal:
            colorization = team_colorization
        food_type = board['foods'][target][0]
        print(term.move_yx(row_position, column_position - 1) + colorization(map_symbols[target_type]) + team_colorization(' ') + food_colorization(map_symbols[food_type]))
    elif target in board['foods']:
        food_type = board['foods'][target][0]
        print(term.move_yx(row_position, column_position - 1) + ' ' + food_colorization(map_symbols[food_type]) + ' ')
    else:
        print(term.move_yx(row_position, column_position - 1) + team_colorization(' ') + colorization(map_symbols[target_type]) + team_colorization(' '))

def display_winner(winner):
    """Display the winner of the game

    Parameters
    ----------
    winner: The team who won the game (int)

    Version
    -------
    specification: Martin Devolder (v.1 13/03/22)
    implementation: Philippe Hennericy (v.1 13/03/22)
    """

    # Clear the terminal
    print(term.clear)

    # Display the winner
    if winner == 1:
        print(term.green("""
        ████████╗███████╗ █████╗ ███╗   ███╗     ██╗    ██╗    ██╗██╗███╗   ██╗███████╗██╗
        ╚══██╔══╝██╔════╝██╔══██╗████╗ ████║    ███║    ██║    ██║██║████╗  ██║██╔════╝██║
           ██║   █████╗  ███████║██╔████╔██║    ╚██║    ██║ █╗ ██║██║██╔██╗ ██║███████╗██║
           ██║   ██╔══╝  ██╔══██║██║╚██╔╝██║     ██║    ██║███╗██║██║██║╚██╗██║╚════██║╚═╝
           ██║   ███████╗██║  ██║██║ ╚═╝ ██║     ██║    ╚███╔███╔╝██║██║ ╚████║███████║██╗
           ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝     ╚═╝     ╚══╝╚══╝ ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝
        """))
    elif winner == 2:
        print(term.blue("""
        ████████╗███████╗ █████╗ ███╗   ███╗    ██████╗     ██╗    ██╗██╗███╗   ██╗███████╗██╗
        ╚══██╔══╝██╔════╝██╔══██╗████╗ ████║    ╚════██╗    ██║    ██║██║████╗  ██║██╔════╝██║
           ██║   █████╗  ███████║██╔████╔██║     █████╔╝    ██║ █╗ ██║██║██╔██╗ ██║███████╗██║
           ██║   ██╔══╝  ██╔══██║██║╚██╔╝██║    ██╔═══╝     ██║███╗██║██║██║╚██╗██║╚════██║╚═╝
           ██║   ███████╗██║  ██║██║ ╚═╝ ██║    ███████╗    ╚███╔███╔╝██║██║ ╚████║███████║██╗
           ╚═╝   ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝    ╚══════╝     ╚══╝╚══╝ ╚═╝╚═╝  ╚═══╝╚══════╝╚═╝
        """))
    else:
        print(term.gray("""
        ███████╗ ██████╗ ██╗   ██╗ █████╗ ██╗     ██╗████████╗██╗   ██╗██╗
        ██╔════╝██╔═══██╗██║   ██║██╔══██╗██║     ██║╚══██╔══╝╚██╗ ██╔╝██║
        █████╗  ██║   ██║██║   ██║███████║██║     ██║   ██║    ╚████╔╝ ██║
        ██╔══╝  ██║▄▄ ██║██║   ██║██╔══██║██║     ██║   ██║     ╚██╔╝  ╚═╝
        ███████╗╚██████╔╝╚██████╔╝██║  ██║███████╗██║   ██║      ██║   ██╗
        ╚══════╝ ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝   ╚═╝      ╚═╝   ╚═╝  
        """))

    print(term.normal_cursor)

def get_distance(first_position, second_position):
    """Get the distance between two points
    
    Parameters
    ----------
    first_position: coordinates of the first position (tuple)
    second_position: coordinates of the second positon (tuple)
    
    Returns
    -------
    distance: Calculated distance (int)

    Version
    -------
    specification: Nicolas Collignon (v.1 19/02/22)
    implementation: Philippe Hennericy (v.1 24/02/22)
    """

    # Spliting the coordinates
    first_position_row = first_position[0]
    first_position_column = first_position[1]

    second_position_row = second_position[0]
    second_position_column = second_position[1]

    # Calculating the distance between the two points and return it
    return max(abs(second_position_row - first_position_row), abs(second_position_column - first_position_column))

def edit_energy(board, wolf_positon, energy):
    """Adds or removes energy to a wolf without exceeding the limits (from 0 to 100)

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    wolf_positon: Position of the wolf to edit energy (tuple)
    energy: Energy to add or remove (int)

    Version
    -------
    specification: Philippe Hennericy (v.1 19/02/22)
    implementation: Gabriel Gofflot (v.1 24/02/22)
    """

    # Getting the wolf energy and adding or removing energy
    current_energy = board['werewolves'][wolf_positon]['energy']
    current_energy += energy

    # Checking if the energy is not negative and not over 100
    if current_energy <= 0:
        # If the energy is at 0, the wolf become pacific
        board['werewolves'][wolf_positon]['pacific'] = True
        current_energy = 0
    elif current_energy > 100:
        current_energy = 100
    board['werewolves'][wolf_positon]['energy'] = current_energy

def orders_conversion(board, orders):
    """Converts the orders into a data structure that can be used by the game

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    orders: The orders of the player (dict)

    Returns
    -------
    converted_orders: The data structure that can be used by the game (dict)

    Version
    -------
    specification: Philippe Hennericy (v.4 25/03/22)
    implementation: Martin Devolder (v.4 25/03/22)
    """

    # Create a sub-function for a code that we need to repeat within this function only
    def parse_instruction(board, instruction, sep, wolves_actioned):
        """Parses an instruction

        Parameters
        ----------
        board: The data structure that contains the map (dict)
        insctruction: The instruction to parse (str)
        sep: separator of the instruction (str)
        wolves_actioned: The wolves that have already been actioned (list)

        Returns
        -------
        parsed_instruction: The parsed instruction (tuple)
        wolves_actioned: The wolves that have already been actioned (list)
        """

        # Separation of the current position and the target
        position = instruction.split(sep)[0]
        target = instruction.split(sep)[1]

        # Isolate the row and column coordinates
        splited_position = position.split('-')
        splited_target = target.split('-')
        position_row = int(splited_position[0])
        position_column = int(splited_position[1])
        target_row = int(splited_target[0])
        target_column = int(splited_target[1])

        # Check if the wolf is not already actioned
        if (position_row, position_column) in wolves_actioned:
            return None, wolves_actioned

        # creation of the parsed instruction
        if sep == ':*':
            parsed_instruction = (((position_row, position_column), (target_row, target_column)), board['werewolves'][(position_row, position_column)]['energy'])
        else:
            parsed_instruction = ((position_row, position_column), (target_row, target_column))
        
        # Add the wolf to the list of wolves that have already been actioned
        if sep == ':@':
            wolves_actioned.append((target_row, target_column))
        else:
            wolves_actioned.append((position_row, position_column))

        # Return the parsed instruction and the edited list of wolves that have already been actioned
        return parsed_instruction, wolves_actioned

    # Creation of the dictionary that contains the orders and creation of the orders
    converted_orders = {'attack': [], 'move': [], 'eat': [], 'pacify': []}

    # Create a list to store wolves that have taken an action this turn
    wolves_actioned = []

    # Analysis of the orders if he has written at least 1 character
    if orders:

        # Separation of the given instructions and integration on them to analyze them
        instructions = orders.split()
        for instruction in instructions:

            # Checking the type of instruction
            if ':*' in instruction:
                parsed_instruction, wolves_actioned = parse_instruction(board, instruction, ':*', wolves_actioned)
                if parsed_instruction:
                    converted_orders['attack'].append(parsed_instruction)
            elif ':@' in instruction:
                parsed_instruction, wolves_actioned = parse_instruction(board, instruction, ':@', wolves_actioned)
                if parsed_instruction:
                    converted_orders['move'].append(parsed_instruction)
            elif ':<' in instruction:
                parsed_instruction, wolves_actioned = parse_instruction(board, instruction, ':<', wolves_actioned)
                if parsed_instruction:
                    converted_orders['eat'].append(parsed_instruction)
            elif 'pacify' in instruction:
                position = instruction.strip(':pacify')
                splited_position = position.split('-')
                position_row = int(splited_position[0])
                position_column = int(splited_position[1])
                if (position_row, position_column) not in wolves_actioned:
                    converted_orders['pacify'].append((position_row, position_column))
                    wolves_actioned.append((position_row, position_column))

    # Converted orders are returned, even if there are none
    return converted_orders

def get_player_orders(board, team):
    """Get the orders of the player

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    team: The team of the player (int)

    Returns
    -------
    orders: The orders of the player (str)

    Version
    -------
    specification: Gabriel Gofflot (v.3 12/03/22)
    implementation: Nicolas Collignon (v.3 12/03/22)
    """

    # Finding the y position of the writing area
    writing_area_y = (board['map'][1] * 2) + 4

    # Move the cursor to the bottom of the terminal
    print(term.move_xy(0, writing_area_y) + term.normal_cursor, end = '')

    # Get the orders
    orders = input('Orders team %d: ' % team)

    # Clear the orders on the terminal and return them
    print(term.move_xy(0, writing_area_y) + ' ' * (len(orders) + 15) + term.hide_cursor)
    return orders

def pacification(board, map_symbols, omega_positions, pacification_orders, team):
    """Pacifies wolves that are near an omega

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    map_symbols: The data structure that contains the symbols of the map (dict)
    omega_positions: The positions of the omega wolves (dict)
    pacification_orders: The wolfs to pacify (list)
    team: The team of the wolf who pacify (int)

    Version
    -------
    specification: Martin Devolder (v.3 13/03/22)
    implementation: Gabriel Gofflot (v.3 13/03/22)
    """

    # Getting the potition of the attacker omega
    omega_position = omega_positions[team]

    # Iteration on the orders of pacification
    for gived_omega in pacification_orders:

        # Pacification of the wolves near the attacker omega
        if omega_position == gived_omega and board['werewolves'][omega_position]['energy'] > 40 \
            and not board['werewolves'][omega_position]['pacific']:

            edit_energy(board, omega_position, -40)

            for wolf in board['werewolves']:
                if get_distance(wolf, omega_position) <= 6 and wolf != omega_position:
                    board['werewolves'][wolf]['pacific'] = True
                    target_team = board['werewolves'][wolf]['team']

                    # Displaying the wolf pacified
                    display_action(board, map_symbols, wolf, 'pacify', target_team, inversion = False)

def calculate_bonus(board):
    """Calculates the bonus of all wolves and applies them

    Parameters
    ----------
    board: The data structure that contains the map (dict)

    Version
    -------
    specification: Nicolas Collignon (v.1 19/02/22)
    implementation: Philippe Hennericy (v.2 27/02/22)
    """

    # Iteration on the wolves
    for wolf_position in board['werewolves']:
        wolf = board['werewolves'][wolf_position]
        bonus = 0

        # Iteration on the other wolves
        for other_wolf_position in board['werewolves']:
            other_wolf = board['werewolves'][other_wolf_position]

            # If the wolf is not the same and is the good team, we calculate the bonus
            if not wolf_position == other_wolf_position and wolf['team'] == other_wolf['team'] \
                and not wolf['pacific'] and not other_wolf['pacific']:

                _distance = get_distance(wolf_position, other_wolf_position)
                if _distance <= 2 and other_wolf['type'] != 'alpha':
                    bonus += 10
                elif _distance <= 4 and other_wolf['type'] == 'alpha':
                    bonus += 30
        
        # Apply the bonus
        wolf['bonus'] = bonus
            
def eat(board, map_symbols, eat_orders, team):
    """Regenerates the energy of wolves who eat food

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    map_symbols: The data structure that contains the symbols of the map (dict)
    eat_orders: The eat orders (list)
    team: The team of the wolf who eat (int)

    Version
    -------
    specification: Philippe Hennericy (v.3 13/03/22)
    implementation: Nicolas Collignon (v.3 13/03/22)
    """

    # Iteration on the orders of eating
    for eat_order in eat_orders:

        # Getting the wolf and the food coordinates
        wolf_coordinates = eat_order[0]
        food_coordinates = eat_order[1]

        # Verify that food is in the board and calculate the distance between wolf's position and food's position and verify the team of the wolf
        if food_coordinates in board['foods'] and get_distance(wolf_coordinates, food_coordinates) <= 1 \
            and board['werewolves'][wolf_coordinates]['team'] == team:

            energy_gain = board['foods'][food_coordinates][1]
            wolf_energy = board['werewolves'][wolf_coordinates]['energy']

            #Update energy
            edit_energy(board, wolf_coordinates, energy_gain)

            # Displaying the eated food
            display_action(board, map_symbols, food_coordinates, 'eat', inversion = False)

            # Update food
            if energy_gain - (100 - wolf_energy) > 0:
                board['foods'][food_coordinates][1] = energy_gain - (100 - wolf_energy)
            else:
                del board['foods'][food_coordinates]
            
def fight(board, map_symbols, fight_orders, team):
    """Calculate the health for each wolf that are attacking

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    map_symbols: The data structure that contains the symbols of the map (dict)
    fight_orders: The fight orders (list)
    team: The team of the wolf who attack (int)

    Returns
    -------
    attack: If there is an attack (bool)

    Version
    -------
    specification: Gabriel Gofflot (v.4 13/03/22)
    implementation: Martin Devolder (v.4 13/03/22)
    """

    # Initialization of the attack as False
    attack = False

    for fight_order in fight_orders:

        # Getting the wolf and the target coordinates
        attacker_position = fight_order[0][0]
        target = fight_order[0][1]

        # Verification that the target is a neighboring square and the attacker is in the good team
        if get_distance(attacker_position, target) == 1 and not board['werewolves'][attacker_position]['pacific'] \
            and board['werewolves'][attacker_position]['team'] == team and target in board['werewolves']:

            # Get the attacker wolf energy and energy bonus
            attacker_energy = fight_order[1]
            attacker_bonus = board['werewolves'][attacker_position]['bonus']

            # Calculate the damage
            attacker_damage = round((attacker_energy + attacker_bonus) / 10)

            # Apply the damage to the target wolf and check if he is dead
            edit_energy(board, target, -attacker_damage)

            # Displaying the attacked wolf
            if board['werewolves'][target]['team'] == team:
                inversion = False
            else:
                inversion = True
            display_action(board, map_symbols, target, 'attack', team, inversion = inversion)

            # Set the attack to True because there is a valid attack
            attack = True
        
    return attack

def move(board, alpha_positions, omega_positions, mooving_orders, team):
    """This function moves a wolf on the map

    Parameters
    ----------
    board: The data structure that contains the map (dict)
    alpha_positions: The positions of the alpha wolves (dict)
    omega_positions: The positions of the omega wolves (dict)
    mooving_orders: The mooving orders (list)
    team: The team of the wolf who move (int)

    Version
    -------
    specification: Gabriel Gofflot (v.3 12/03/22)
    implementation: Gabriel Gofflot(v.3 12/03/22)
    """

    # Iteration on the orders of mooving
    for mooving_order in mooving_orders:

        # Getting the wolf and the destination coordinates
        coordinates = mooving_order[0]
        destination = mooving_order[1]

        # Verification that the destination isn't a wolf or a wall
        if not destination in board['werewolves'] \
            and (destination[0] > 0 and destination[0] <= board['map'][0]) \
                and (destination[1] > 0 and destination[1] <= board['map'][1]) \
                    and coordinates in board['werewolves'] and board['werewolves'][coordinates]['team'] == team \
                        and get_distance(coordinates, destination) == 1:
            
            # Move the wolf
            board['werewolves'][destination] = board['werewolves'][coordinates]
            del board['werewolves'][coordinates]
            
            # Update the alpha and omega positions
            if board['werewolves'][destination]['type'] == 'alpha':
                team = board['werewolves'][destination]['team']
                alpha_positions[team] = destination
            elif board['werewolves'][destination]['type'] == 'omega':
                team = board['werewolves'][destination]['team']
                omega_positions[team] = destination



# main function
def play_game(map_path, group_1, type_1, group_2, type_2):
    """Play a game.
    
    Parameters
    ----------
    map_path: path of map file (str)
    group_1: group of player 1 (int)
    type_1: type of player 1 (str)
    group_2: group of player 2 (int)
    type_2: type of player 2 (str)
    
    Notes
    -----
    Player type is either 'human', 'AI' or 'remote'.
    
    If there is an external referee, set group id to 0 for remote player.
    
    """
    
    board, alpha_positions, omega_positions = read_config(map_path)

    # create connection, if necessary
    if type_1 == 'remote':
        connection = create_connection(group_2, group_1, verbose = True)
    elif type_2 == 'remote':
        connection = create_connection(group_1, group_2, verbose = True)

    ongoing_game = True
    number_rounds = 1
    rounds_without_fight = 0

    # Definition of the board characters
    map_symbols = {
        'normal': 'Θ',
        'alpha': 'α',
        'omega': 'ω',
        'apples': 'Ѽ',
        'berries': 'ಹ',
        'deers': 'ܮ',
        'mice': 'ක',
        'rabbits': 'Ꮕ'
    }

    while ongoing_game and rounds_without_fight < 200:

        # Waiting 0.5 second at the beginning of each round
        time.sleep(0.5)
    
        # Displaying the map at the beginning of each round
        if number_rounds == 1:
            display_map(board)
        display_update(board, map_symbols, number_rounds)

        # Get orders of player 1 and notify them to player 2, if necessary
        if type_1 == 'remote':
            orders_team_one = get_remote_orders(connection)
        elif type_1 == 'human':
            orders_team_one = get_player_orders(board, 1)
        else:
            orders_team_one = get_AI_orders(board, 1, alpha_positions, omega_positions)
            if type_2 == 'remote':
                notify_remote_orders(connection, orders_team_one)
        
        # Get orders of player 2 and notify them to player 1, if necessary
        if type_2 == 'remote':
            orders_team_two = get_remote_orders(connection)
        elif type_2 == 'human':
            orders_team_two = get_player_orders(board, 2)
        else:
            orders_team_two = get_AI_orders(board, 2, alpha_positions, omega_positions)
            if type_1 == 'remote':
                notify_remote_orders(connection, orders_team_two)
        
        # Convert str orders to dict
        orders_team_one = orders_conversion(board, orders_team_one)
        orders_team_two = orders_conversion(board, orders_team_two)

        # Application of the pacification orders of each team
        pacification(board, map_symbols, omega_positions, orders_team_one['pacify'], 1)
        pacification(board, map_symbols, omega_positions, orders_team_two['pacify'], 2)

        # Calculation and application of bonuses
        calculate_bonus(board)

        # Application of the eat orders
        eat(board, map_symbols, orders_team_one['eat'], 1)
        eat(board, map_symbols, orders_team_two['eat'], 2)

        # Application of the fight orders
        attack_one = fight(board, map_symbols, orders_team_one['attack'], 1)
        attack_two = fight(board, map_symbols, orders_team_two['attack'], 2)

        # Application of the move orders
        move(board, alpha_positions, omega_positions, orders_team_one['move'], 1)
        move(board, alpha_positions, omega_positions, orders_team_two['move'], 2)

        # Reset of bonuses and pacifications
        for wolf in board['werewolves']:
            board['werewolves'][wolf]['bonus'] = 0
            if board['werewolves'][wolf]['pacific'] == True and board['werewolves'][wolf]['energy'] > 0:
                board['werewolves'][wolf]['pacific'] = False
        
        # Calculation of the number of rounds without fight
        if not attack_one and not attack_two:
            rounds_without_fight += 1
        else:
            rounds_without_fight = 0

        # Check if the game is over
        energy_team_one = board['werewolves'][alpha_positions[1]]['energy']
        energy_team_two = board['werewolves'][alpha_positions[2]]['energy']
        if energy_team_one == 0 and energy_team_two == 0:
            ongoing_game = False
            winner = None
        elif energy_team_one == 0:
            ongoing_game = False
            winner = 2
        elif energy_team_two == 0:
            ongoing_game = False
            winner = 1
        else:
            number_rounds += 1

    # Close connection, if necessary
    if type_1 == 'remote' or type_2 == 'remote':
        time.sleep(1)
        close_connection(connection)
    
    # If the game is over cause of the number of rounds, choosing a winner
    if rounds_without_fight == 200:
        total_energy_one = 0
        total_energy_two = 0
        for wolf in board['werewolves']:
            if board['werewolves'][wolf]['team'] == 1:
                total_energy_one += board['werewolves'][wolf]['energy']
            else:
                total_energy_two += board['werewolves'][wolf]['energy']
        if total_energy_one > total_energy_two:
            winner = 1
        elif total_energy_one < total_energy_two:
            winner = 2
        else:
            winner = None
    
    # Displaying the last state of the board and the winner
    display_update(board, map_symbols, number_rounds)
    display_winner(winner)